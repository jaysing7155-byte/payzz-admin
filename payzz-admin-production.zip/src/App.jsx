import React, { useState } from "react";

export default function App() {
  const [status, setStatus] = useState("");

  return (
    <div style={{padding:20}}>
      <h2>Payzz Admin Dashboard</h2>
      <button onClick={()=>setStatus("Approved ✅")}>Approve</button>
      <button onClick={()=>setStatus("Rejected ❌")}>Reject</button>
      <p>{status}</p>
    </div>
  );
}
